package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.shubhamjhunjhunwala.popularmovies.Data.FavouritesContract;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.OfflineMovie;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Responce;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Review;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Video;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.JSONUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.NetworkUtils;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.parceler.Parcels;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;

/**
 * Created by shubham on 12/01/18.
 */

public class DetailsActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Responce>, VideosAdapter.ItemClickListener {

    public static final int VIDEOS_LOADER = 100;
    public static final String MOVIE_ID_KEY = "Movie ID";

    public static final String YOUTUBE_APP_BASE_LINK = "vnd.youtube:";
    public static final String YOUTUBE_WEB_BASE_LINK = "http://www.youtube.com/watch?v=";

    public ImageView imageView;
    public TextView titleTextView;
    public TextView ratingTextView;
    public TextView releaseDateTextView;
    public TextView synopsisTextView;

    public CheckBox favouritesCheckbox;
    public RecyclerView videosListView;
    public RecyclerView reviewsRecyclerView;

    public Video[] videos;
    public VideosAdapter videosAdapter;

    public Review[] reviews;
    public ReviewsAdapter reviewsAdapter;

    public Movie movie;
    public OfflineMovie offlineMovie;

    public String movieID;
    public String title;
    public byte[] thumbnailAsByteArray;
    public String description, userRating, releaseDate;

    public boolean movieIsPresent;

    public boolean isOffline;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        imageView = (ImageView) findViewById(R.id.imageView);
        titleTextView = (TextView) findViewById(R.id.title_text_view);
        ratingTextView = (TextView) findViewById(R.id.user_rating_text_view);
        releaseDateTextView = (TextView) findViewById(R.id.release_date_text_view);
        synopsisTextView = (TextView) findViewById(R.id.synopsis_text_view);
        favouritesCheckbox = (CheckBox) findViewById(R.id.favourites_checkbox);
        videosListView = (RecyclerView) findViewById(R.id.videos_list_view);
        reviewsRecyclerView = (RecyclerView) findViewById(R.id.reviews_list_view);

        Intent intent = getIntent();

        isOffline = intent.getBooleanExtra("Is Offline", false);

        Log.d("Disconnected", Boolean.toString(isOffline));

        movie = (Movie) Parcels.unwrap(intent.getParcelableExtra("Movie"));

        if ( !isOffline ) {
            movie = (Movie) Parcels.unwrap(intent.getParcelableExtra("Movie"));

            Glide.with(this).load(movie.getImageURL()).into(imageView);

            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    try {
                        Bitmap bitmap = Picasso.with(DetailsActivity.this).load(movie.getImageURL()).get();
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                        thumbnailAsByteArray = byteArrayOutputStream.toByteArray();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            }.execute();

            movieID = movie.getMovieID();
            title = movie.getTitle();
            userRating = movie.getVoteAverage();
            description = movie.getSynopsis();
            releaseDate = movie.getReleaseDate();

            getSupportLoaderManager().initLoader(VIDEOS_LOADER, null, this);

            startVideosLoader(movie.getMovieID());
        } else {
            offlineMovie = (OfflineMovie) Parcels.unwrap(intent.getParcelableExtra("Movie"));

            movieID = offlineMovie.getMovieID();
            title = offlineMovie.getTitle();
            thumbnailAsByteArray = offlineMovie.getImageAsByteArray();
            userRating = offlineMovie.getVoteAverage();
            description = offlineMovie.getSynopsis();
            releaseDate = offlineMovie.getReleaseDate();
        }

        titleTextView.setText(movie.getTitle());
        ratingTextView.setText("Rating: " + movie.getVoteAverage());
        releaseDateTextView.setText("Released on: " + movie.getReleaseDate());
        synopsisTextView.setText(movie.getSynopsis());

        try {
            movieIsPresent = checkIfMovieIsPresentInDatabase();
        } catch (android.database.CursorIndexOutOfBoundsException e) {
            Toast.makeText(this, "Cursor threw an exception", Toast.LENGTH_SHORT).show();
        }

        if (movieIsPresent) {
            favouritesCheckbox.setChecked(true);
        }

        favouritesCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b && thumbnailAsByteArray != null) {
                    addMovieToFavourites();
                } else if (!b && thumbnailAsByteArray != null) {
                    removeMovieFromFavourites();
                } else {
                    favouritesCheckbox.setChecked(!b);
                }
            }
        });
    }

    @Override
    public Loader<Responce> onCreateLoader(int i, final Bundle bundle) {
        return new AsyncTaskLoader<Responce>(this) {

            Responce responce = new Responce("", "");

            @Override
            protected void onStartLoading() {
                if (!responce.getVideosResponce().equals("") && !responce.getReviewsResponce().equals("")) {
                    deliverResult(responce);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Responce loadInBackground() {
                URL videosURL = NetworkUtils.buildVideosURL(bundle.getString(MOVIE_ID_KEY));
                URL reviewsURL = NetworkUtils.buildReviewsURL(bundle.getString(MOVIE_ID_KEY));

                String videosResponce = null;
                String reviewsResponce = null;

                if (videosURL == null || reviewsURL == null) {
                    return null;
                }

                try {
                    videosResponce = NetworkUtils.getResponseFromHTTPUrl(videosURL);
                    reviewsResponce = NetworkUtils.getResponseFromHTTPUrl(reviewsURL);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Responce response = new Responce(videosResponce, reviewsResponce);

                return response;
            }

            @Override
            public void deliverResult(Responce data) {
                responce.setVideosResponce(data.getVideosResponce());
                responce.setReviewsResponce(data.getReviewsResponce());

                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Responce> loader, Responce responce) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false) {
            @Override
            public boolean canScrollVertically() {
                return true;
            }
        };

        videosListView.setLayoutManager(linearLayoutManager);

        videosListView.setHasFixedSize(true);

        Log.d("Videos Result: ", responce.getVideosResponce());
        Log.d("Reviews Result: ", responce.getReviewsResponce());

        LinearLayoutManager reviewsLinearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        reviewsRecyclerView.setLayoutManager(reviewsLinearLayoutManager);
        reviewsRecyclerView.setHasFixedSize(true);

        try {
            videos = JSONUtils.getVideosFromJSONResponce(responce.getVideosResponce());
            videosAdapter = new VideosAdapter(videos, this);
            videosListView.setAdapter(videosAdapter);

            reviews = JSONUtils.getReviewsFromJSONResponce(responce.getReviewsResponce());
            reviewsAdapter = new ReviewsAdapter(reviews);
            reviewsRecyclerView.setAdapter(reviewsAdapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLoaderReset(Loader<Responce> loader) {

    }

    public void startVideosLoader(String movieID) {
        Bundle query = new Bundle();
        query.putString(MOVIE_ID_KEY, movieID);

        android.support.v4.app.LoaderManager loaderManager = getSupportLoaderManager();

        android.support.v4.content.Loader<String> loader = loaderManager.getLoader(VIDEOS_LOADER);

        if (loader == null) {
            loaderManager.initLoader(VIDEOS_LOADER, query, this);
        } else {
            loaderManager.restartLoader(VIDEOS_LOADER, query, this);
        }
    }

    @Override
    public void onItemClicked(int position) {
        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(YOUTUBE_APP_BASE_LINK + videos[position].getkey()));
        Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(YOUTUBE_WEB_BASE_LINK + videos[position].getkey()));

        try {
            startActivity(appIntent);
        } catch (ActivityNotFoundException e) {
            startActivity(webIntent);
        }
    }

    public void addMovieToFavourites() {
        ContentValues contentValues = new ContentValues();

        contentValues.put(FavouritesContract.FavouritesEntry._ID, Integer.parseInt(movieID));
        contentValues.put(FavouritesContract.FavouritesEntry.COLUMN_NAME, movie.getTitle());
        contentValues.put(FavouritesContract.FavouritesEntry.COLUMN_IMAGE, thumbnailAsByteArray);
        contentValues.put(FavouritesContract.FavouritesEntry.COLUMN_DESCRIPTION, movie.getSynopsis());
        contentValues.put(FavouritesContract.FavouritesEntry.COLUMN_RATINGS, movie.getVoteAverage());
        contentValues.put(FavouritesContract.FavouritesEntry.COLUMN_RELEASE_DATE, movie.getReleaseDate());

        Uri uri = getContentResolver().insert(FavouritesContract.FavouritesEntry.CONTENT_URI, contentValues);

        if (uri != null) {
            Toast.makeText(this, "Successfully Added to Database", Toast.LENGTH_SHORT).show();
        }
    }

    public void removeMovieFromFavourites() {
        int id = getContentResolver().delete(FavouritesContract.FavouritesEntry.CONTENT_URI.buildUpon().appendPath(movie.getMovieID()).build(),
                                                null,
                                                null);

        if (id > 0) {
            Toast.makeText(this, "Successfully Removed from Database", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean checkIfMovieIsPresentInDatabase() {
        Log.d("Uri", FavouritesContract.FavouritesEntry.CONTENT_URI.toString());

        Cursor cursor = getContentResolver().query(FavouritesContract.FavouritesEntry.CONTENT_URI.buildUpon().appendPath(movieID).build(),
                null,
                null,
                null,
                null);

        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            Toast.makeText(this, "Movie Present", Toast.LENGTH_SHORT).show();
            return true;
        }

        if (cursor != null) {
            cursor.close();
        }

        return false;
    }
}
