package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Keys;

/**
 * Created by shubham on 12/01/18.
 */

public class SettingsActivity extends AppCompatActivity {

    public CheckBox topRatedCheckbox;
    public CheckBox mostPopularCheckbox;

    SharedPreferences sharedPref;
    SharedPreferences.Editor sharedPrefEditor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        topRatedCheckbox = (CheckBox) findViewById(R.id.checkbox_top_rated);
        mostPopularCheckbox = (CheckBox) findViewById(R.id.checkbox_most_popular);

        sharedPref = getSharedPreferences("Settings", Context.MODE_PRIVATE);
        String defaultValue = "Top Rated";
        String value = sharedPref.getString(Keys.SORT_BY, defaultValue);

        sharedPrefEditor = sharedPref.edit();

        if (value.equals("Top Rated")) {
            topRatedCheckbox.setChecked(true);
        } else if (value.equals("Most Popular")) {
            mostPopularCheckbox.setChecked(true);
        }

        mostPopularCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (mostPopularCheckbox.isChecked()) {
                    topRatedCheckbox.setChecked(false);
                    sharedPrefEditor.putString(Keys.SORT_BY, "Most Popular");
                    sharedPrefEditor.commit();
                } else {
                    topRatedCheckbox.setChecked(true);
                    sharedPrefEditor.putString(Keys.SORT_BY, "Top Rated");
                    sharedPrefEditor.commit();
                }
            }
        });

        topRatedCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (topRatedCheckbox.isChecked()) {
                    mostPopularCheckbox.setChecked(false);
                    sharedPrefEditor.putString(Keys.SORT_BY, "Top Rated");
                    sharedPrefEditor.commit();
                } else {
                    mostPopularCheckbox.setChecked(true);
                    sharedPrefEditor.putString(Keys.SORT_BY, "Most Popular");
                    sharedPrefEditor.commit();
                }
            }
        });
    }
}
