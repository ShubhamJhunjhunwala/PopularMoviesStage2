package com.app.shubhamjhunjhunwala.popularmovies;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.bumptech.glide.Glide;

/**
 * Created by shubham on 09/01/18.
 */

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MovieViewHolder> {

    private Movie[] movies;

    public ItemClickListener mItemClickListener;

    public MoviesAdapter(Movie[] movies, ItemClickListener itemClickListener) {

        this.movies = new Movie[movies.length];

        this.mItemClickListener = itemClickListener;

        for (int i = 0, n = movies.length; i < n; i++) {
            this.movies[i] = movies[i];
        }
    }

    @Override
    public MoviesAdapter.MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.grid_item, parent, false);

        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MoviesAdapter.MovieViewHolder holder, int position) {
        holder.bind(movies[position].getImageURL(), movies[position].getTitle());
    }

    @Override
    public int getItemCount() {
        if (movies.length > 0) {
            return movies.length;
        }

        return 0;
    }

    public interface ItemClickListener {
        void onItemClicked(int position);
    }

    public class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView imageView;
        public TextView textView;

        public MovieViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            textView = (TextView) itemView.findViewById(R.id.textView);

            itemView.setOnClickListener(this);
        }

        public void bind (String imageURL, String title) {
            textView.setText(title);

            Glide.with(itemView.getContext()).load(imageURL).into(imageView);
        }

        @Override
        public void onClick(View view) {
            mItemClickListener.onItemClicked(getAdapterPosition());
        }
    }
}
