package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Video;

/**
 * Created by shubham on 17/02/18.
 */

public class VideosAdapter extends RecyclerView.Adapter<VideosAdapter.VideosViewHolder> {

    private Video[] videos;

    public ItemClickListener mItemClickListener;

    public VideosAdapter (Video[] videos, ItemClickListener itemClickListener) {
        this.videos = new Video[videos.length];
        mItemClickListener = itemClickListener;

        for (int i = 0, length = videos.length; i < length; i++) {
            this.videos[i] = videos[i];
        }
    }

    @Override
    public VideosViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.videos_list_item, parent, false);

        return new VideosViewHolder(view);
    }

    @Override
    public void onBindViewHolder(VideosViewHolder holder, int position) {
        holder.bind(videos[position].getTitle());
    }

    @Override
    public int getItemCount() {
        if (videos.length > 0) {
            return videos.length;
        }
        return 0;
    }

    public interface ItemClickListener {
        void onItemClicked(int position);
    }

    public class VideosViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView playButtonImageView;
        public TextView titleTextView;

        public VideosViewHolder(View itemView) {
            super(itemView);

            playButtonImageView = (ImageView) itemView.findViewById(R.id.play_button);
            titleTextView = (TextView) itemView.findViewById(R.id.video_title_text_view);

            playButtonImageView.setOnClickListener(this);
        }

        public void bind(String title) {
            titleTextView.setText(title);
        }

        @Override
        public void onClick(View view) {
            mItemClickListener.onItemClicked(getAdapterPosition());
        }
    }
}
