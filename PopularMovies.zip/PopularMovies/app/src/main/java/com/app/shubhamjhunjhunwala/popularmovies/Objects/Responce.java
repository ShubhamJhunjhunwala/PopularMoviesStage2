package com.app.shubhamjhunjhunwala.popularmovies.Objects;

/**
 * Created by shubham on 19/02/18.
 */

public class Responce {

    public String videosResponce;
    public String reviewsResponce;

    public Responce(String videosResponce, String reviewsResponce) {
        this.videosResponce = videosResponce;
        this.reviewsResponce = reviewsResponce;
    }

    public String getVideosResponce() {
        return videosResponce;
    }

    public void setVideosResponce(String videosResponce) {
        this.videosResponce = videosResponce;
    }

    public String getReviewsResponce() {
        return reviewsResponce;
    }

    public void setReviewsResponce(String reviewsResponce) {
        this.reviewsResponce = reviewsResponce;
    }
}
