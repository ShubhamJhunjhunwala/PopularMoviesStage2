package com.app.shubhamjhunjhunwala.popularmovies.Objects;

/**
 * Created by shubham on 18/02/18.
 */

public class Review {

    public String name;
    public String review;

    public Review(String name, String review) {
        this.name = name;
        this.review = review;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
