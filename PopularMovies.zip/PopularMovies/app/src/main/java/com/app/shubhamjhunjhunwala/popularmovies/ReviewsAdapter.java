package com.app.shubhamjhunjhunwala.popularmovies;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Review;
import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

/**
 * Created by shubham on 18/02/18.
 */

public class ReviewsAdapter extends RecyclerView.Adapter<ReviewsAdapter.ReviewsViewHolder> {

    private Review[] reviews;

    public ReviewsAdapter(Review[] reviews) {

        this.reviews = new Review[reviews.length];

        for (int i = 0, n = reviews.length; i < n; i++) {
            this.reviews[i] = reviews[i];
        }
    }

    @Override
    public ReviewsAdapter.ReviewsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.reviews_list_item, parent, false);

        return new ReviewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ReviewsViewHolder holder, int position) {
        holder.bind(reviews[position].getName(), reviews[position].getReview());
    }

    @Override
    public int getItemCount() {
        if (reviews.length > 0) {
            return reviews.length;
        }

        return 0;
    }

    public class ReviewsViewHolder extends RecyclerView.ViewHolder {

        public TextView nameTextView;
        public TextView reviewTextView;

        public ReviewsViewHolder(View itemView) {
            super(itemView);

            nameTextView = (TextView) itemView.findViewById(R.id.name_text_view);
            reviewTextView = (TextView) itemView.findViewById(R.id.review_text_view);
        }

        public void bind (String name, String review) {
            nameTextView.setText(name);
            reviewTextView.setText(review);
        }
    }
}
