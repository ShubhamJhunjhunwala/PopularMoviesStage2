package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Keys;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.JSONUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.NetworkUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.ResponsesAsyncTask;

import org.json.JSONException;
import org.parceler.Parcel;
import org.parceler.Parcels;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public RecyclerView recyclerView;
    public CardView loadingCardView;

    public String response = null;
    public Movie[] movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }

        ImageButton imageButton = (ImageButton) findViewById(R.id.settings_image_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        loadingCardView = (CardView) findViewById(R.id.loading_card_view);

        SharedPreferences sharedPref = getSharedPreferences("Settings", Context.MODE_PRIVATE);
        String defaultValue = "Top Rated";
        String value = sharedPref.getString(Keys.SORT_BY, defaultValue);

        URL url = null;

        if (value.equals("Top Rated")) {
            url = NetworkUtils.buildTopRatedURL();
        } else if (value.equals("Most Popular")) {
            url = NetworkUtils.buildMostPopularURL();
        }

        Log.d("Built URL", url.toString());

        ResponsesAsyncTask asyncTask = new ResponsesAsyncTask(loadingCardView, recyclerView, this);

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (isConnected) {
            asyncTask.execute(url);
        } else {
            Intent intent = new Intent(this, NoInternetActivity.class);
            startActivity(intent);
        }
    }
}
