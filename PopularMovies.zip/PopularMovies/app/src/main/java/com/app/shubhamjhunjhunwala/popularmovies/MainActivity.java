package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.Toast;

import com.app.shubhamjhunjhunwala.popularmovies.Data.FavouritesContract;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Keys;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.OfflineMovie;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.JSONUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.NetworkUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.ResponsesAsyncTask;

import org.json.JSONException;
import org.parceler.Parcel;
import org.parceler.Parcels;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>, OfflineMoviesAdapter.ItemClickListener{

    public RecyclerView recyclerView;
    public CardView loadingCardView;

    public String response = null;
    public Movie[] movies;

    public ArrayList<OfflineMovie> offlineMovies;
    public OfflineMoviesAdapter offlineMoviesAdapter;

    public final int LOADER_ID = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }

        ImageButton imageButton = (ImageButton) findViewById(R.id.settings_image_button);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        loadingCardView = (CardView) findViewById(R.id.loading_card_view);

        SharedPreferences sharedPref = getSharedPreferences("Settings", Context.MODE_PRIVATE);
        String defaultValue = "Top Rated";
        String value = sharedPref.getString(Keys.SORT_BY, defaultValue);

        URL url = null;

        if (value.equals("Top Rated")) {
            url = NetworkUtils.buildTopRatedURL();
        } else if (value.equals("Most Popular")) {
            url = NetworkUtils.buildMostPopularURL();
        }

        Log.d("Built URL", url.toString());

        ResponsesAsyncTask asyncTask = new ResponsesAsyncTask(loadingCardView, recyclerView, this);

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (isConnected) {
            asyncTask.execute(url);
        } else if (!checkIfFavouritesPresent()) {
            Intent intent = new Intent(this, NoInternetActivity.class);
            startActivity(intent);
        } else {
            displayOfflineResults();
        }
    }

    public boolean checkIfFavouritesPresent() {
        Cursor cursor = getContentResolver().query(FavouritesContract.FavouritesEntry.CONTENT_URI,
                                                    null,
                                                    null,
                                                    null,
                                                    null);

        if (cursor != null) {
            cursor.close();

            if (cursor.getCount() > 0) {
                return true;
            }
        }

        return false;
    }

    public void displayOfflineResults() {
        Toast.makeText(this, "Displaying Offline Results", Toast.LENGTH_SHORT).show();

        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(staggeredGridLayoutManager);
        recyclerView.setHasFixedSize(true);

        getSupportLoaderManager().initLoader(LOADER_ID, null, this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        getSupportLoaderManager().restartLoader(LOADER_ID, null, this);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(this) {

            Cursor favourites = null;

            @Override
            protected void onStartLoading() {
                if (favourites != null) {
                    deliverResult(favourites);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Cursor loadInBackground() {
                try {
                    Cursor cursor = getContentResolver().query(FavouritesContract.FavouritesEntry.CONTENT_URI,
                                                    null,
                                                    null,
                                                    null,
                                                    null);

                    Log.d("Background", Integer.toString(cursor.getCount()));

                    return cursor;
                } catch (Exception e) {
                    Log.e("Main Activity Loader", "Failed to load data");
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void deliverResult(Cursor data) {
                favourites = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        offlineMovies = new ArrayList<>();

        data.moveToFirst();

        if (data.isAfterLast()) {
            try {
                do {
                    int id = data.getInt(data.getColumnIndex(FavouritesContract.FavouritesEntry._ID));

                    String movieID = Integer.toString(id);

                    OfflineMovie offlineMovie = new OfflineMovie(data.getString(data.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_NAME)),
                            data.getBlob(data.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_IMAGE)),
                            "",
                            "",
                            "",
                            movieID);
                } while (data.moveToNext());
            } catch (Exception e) {
                Log.d("onLoadFinished", e.getMessage());
            }
        } else {
            Log.d("onLoadFinished", "No Data in Cursor");
        }

        Log.d("Data", offlineMovies.toString());

        offlineMoviesAdapter = new OfflineMoviesAdapter(offlineMovies, this);

        recyclerView.setAdapter(offlineMoviesAdapter);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onItemClicked(String id) {
        Cursor cursor = getContentResolver().query(FavouritesContract.FavouritesEntry.CONTENT_URI.buildUpon().appendPath(id).build(),
                                                    null,
                                                    null,
                                                    null,
                                                    null);

        if (cursor == null) {
            Log.d("OnItemClicked", "NULL Cursor");
            return;
        }

        cursor.moveToLast();

        OfflineMovie offlineMovie = new OfflineMovie(cursor.getString(cursor.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_NAME)),
                                                        cursor.getBlob(cursor.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_IMAGE)),
                                                        cursor.getString(cursor.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_DESCRIPTION)),
                                                        cursor.getString(cursor.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_RATINGS)),
                                                        cursor.getString(cursor.getColumnIndex(FavouritesContract.FavouritesEntry.COLUMN_RELEASE_DATE)),
                                                        id);

        Intent intent = new Intent(this, DetailsActivity.class);
        intent.putExtra("Is Offline", true);
        intent.putExtra("Movie", Parcels.wrap(offlineMovie));

        startActivity(intent);
    }
}
