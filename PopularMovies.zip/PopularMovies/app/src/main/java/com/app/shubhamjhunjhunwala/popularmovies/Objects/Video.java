package com.app.shubhamjhunjhunwala.popularmovies.Objects;

/**
 * Created by shubham on 17/02/18.
 */

public class Video {

    String title;
    String key;

    public Video(String title, String key) {
        this.title = title;
        this.key = key;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getkey() {
        return key;
    }

    public void setkey(String key) {
        this.key = key;
    }
}
