package com.app.shubhamjhunjhunwala.popularmovies.Utils;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;

import com.app.shubhamjhunjhunwala.popularmovies.DetailsActivity;
import com.app.shubhamjhunjhunwala.popularmovies.MoviesAdapter;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;

import org.json.JSONException;
import org.parceler.Parcels;

import java.io.IOException;
import java.net.URL;

/**
 * Created by shubham on 13/01/18.
 */

public class ResponsesAsyncTask extends AsyncTask<URL, Void, String> implements MoviesAdapter.ItemClickListener {

    public CardView loadingCardView;
    public RecyclerView recyclerView;

    public Context context;

    public String response = null;
    public Movie[] movies;

    public ResponsesAsyncTask(CardView loadingCardView, RecyclerView recyclerView, Context context) {
        this.loadingCardView = loadingCardView;
        this.recyclerView = recyclerView;
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        loadingCardView.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }

    @Override
    protected String doInBackground(URL... urls) {
        try {
            response = NetworkUtils.getResponseFromHTTPUrl(urls[0]);
            movies = JSONUtils.getDataFromJSONResponce(response);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (response != null) {
            return response;
        }

        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        Log.d("JSON Responce", response);

        for (int i = 0, n = movies.length; i < n; i++) {
            Log.d("Data at " + String.valueOf(i + 1), movies[i].getTitle());
        }

        attachAdapter();

        loadingCardView.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
    }

    public void attachAdapter() {
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(staggeredGridLayoutManager);

        recyclerView.setHasFixedSize(true);

        MoviesAdapter moviesAdapter = new MoviesAdapter(movies, this);

        recyclerView.setAdapter(moviesAdapter);
    }

    @Override
    public void onItemClicked(int position) {
        Movie movie = movies[position];
        Intent intent = new Intent(context, DetailsActivity.class);
        intent.putExtra("Is Offline", false);
        intent.putExtra("Movie", Parcels.wrap(movie));
        context.startActivity(intent);
    }
}
