package com.app.shubhamjhunjhunwala.popularmovies.Objects;

import org.parceler.Parcel;

/**
 * Created by shubham on 02/03/18.
 */

@Parcel
public class OfflineMovie {

    public String title;
    public byte[] imageAsByteArray;
    public String synopsis;
    public String voteAverage;
    public String releaseDate;
    public String movieID;

    public OfflineMovie() {

    }

    public OfflineMovie(String title, byte[] image, String synopsis, String voteAverage, String releaseDate, String movieID) {
        this.title = title;
        this.imageAsByteArray = image;
        this.synopsis = synopsis;
        this.voteAverage = voteAverage;
        this.releaseDate = releaseDate;
        this.movieID = movieID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public byte[] getImageAsByteArray() {
        return imageAsByteArray;
    }

    public void setImageURL(byte[] image) {
        this.imageAsByteArray = image;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(String voteAverage) {
        this.voteAverage = voteAverage;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getMovieID() {
        return movieID;
    }

    public void setMovieID(String movieID) {
        this.movieID = movieID;
    }
}
