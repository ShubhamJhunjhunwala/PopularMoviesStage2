package com.app.shubhamjhunjhunwala.popularmovies.Data;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by shubham on 09/02/18.
 */

public class FavouritesContract {

    public final static String AUTHORITY = "com.app.shubhamjhunjhunwala.popularmovies";
    public final static Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);
    public final static String PATH_FAVOURITES = "favourites";

    public static final class FavouritesEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(PATH_FAVOURITES).build();

        public static final String TABLE_NAME = "favourites";

        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_RELEASE_DATE = "date";
        public static final String COLUMN_RATINGS = "ratings";
        public static final String COLUMN_DESCRIPTION = "description";
        public static final String COLUMN_IMAGE = "image";
    }
}
