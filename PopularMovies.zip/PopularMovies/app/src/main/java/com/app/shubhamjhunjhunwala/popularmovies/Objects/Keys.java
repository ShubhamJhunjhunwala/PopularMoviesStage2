package com.app.shubhamjhunjhunwala.popularmovies.Objects;

/**
 * Created by shubham on 12/01/18.
 */

public class Keys {
    public static String SORT_BY = "Sort By";
}
