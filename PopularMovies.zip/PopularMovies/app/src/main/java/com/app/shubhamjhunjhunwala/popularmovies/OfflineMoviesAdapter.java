package com.app.shubhamjhunjhunwala.popularmovies;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.shubhamjhunjhunwala.popularmovies.Data.FavouritesContract;
import com.app.shubhamjhunjhunwala.popularmovies.Objects.OfflineMovie;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

/**
 * Created by shubham on 01/03/18.
 */

public class OfflineMoviesAdapter extends RecyclerView.Adapter<OfflineMoviesAdapter.MovieViewHolder> {

    private ArrayList<OfflineMovie> offlineMovies;

    public interface ItemClickListener {
        void onItemClicked(String id);
    }

    public ItemClickListener mItemClickListener;

    public OfflineMoviesAdapter (ArrayList<OfflineMovie> offlineMovies, ItemClickListener itemClickListener) {
        this.offlineMovies = offlineMovies;
        this.mItemClickListener = itemClickListener;
    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.grid_item, parent, false);

        return new OfflineMoviesAdapter.MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {

        holder.itemView.setTag(offlineMovies.get(position).getMovieID());
        holder.textView.setText(offlineMovies.get(position).getTitle());

        byte[] imageAsByteArray = offlineMovies.get(position).getImageAsByteArray();

        Bitmap bmp = BitmapFactory.decodeByteArray(imageAsByteArray, 0, imageAsByteArray.length);

        holder.imageView.setImageBitmap(Bitmap.createScaledBitmap(bmp, holder.imageView.getWidth(), holder.imageView.getHeight(), false));
    }

    @Override
    public int getItemCount() {
        return offlineMovies.size();
    }

    public class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView imageView;
        public TextView textView;

        public MovieViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            textView = (TextView) itemView.findViewById(R.id.textView);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            mItemClickListener.onItemClicked(itemView.getTag().toString());
        }
    }
}
